# Anya Saldo — Android project

Aplikasi Android sederhana bertema pink pastel untuk saldo, riwayat transaksi, input manual, dan deteksi pemasukan dari notifikasi DANA.

## Cara membuat APK
1. Unduh dan ekstrak ZIP ini di komputer.
2. Buka folder `AnyaSaldoAndroid` memakai Android Studio versi terbaru.
3. Tunggu Gradle Sync selesai (perlu koneksi internet untuk mengunduh Android Gradle Plugin dan Kotlin).
4. Pilih **Build > Build APK(s)**.
5. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara mengaktifkan pencatatan otomatis
1. Pasang APK pada HP Android.
2. Buka **Anya Saldo**.
3. Tekan **Aktifkan deteksi notifikasi DANA**.
4. Di pengaturan Android, aktifkan izin notifikasi untuk Anya Saldo.
5. Pastikan aplikasi DANA mengirim notifikasi transaksi uang masuk. Tes dengan transaksi yang nominalnya diketahui dan cocokkan dengan riwayat DANA.

## Batasan dan keamanan
- Kode memproses notifikasi dari package `id.dana` dan hanya mencatat jika teks mengandung frasa uang masuk yang dikenali serta nominal `Rp...`.
- Format notifikasi DANA bisa berbeda menurut versi/aplikasi/jenis transaksi. Jika frasa tidak cocok, transaksi tidak akan otomatis tercatat. Periksa hasilnya dan cocokkan dengan aplikasi DANA.
- Ini bukan integrasi API resmi DANA dan tidak bisa menjamin semua notifikasi terdeteksi. Tidak membaca saldo akun DANA secara langsung.
- Data transaksi disimpan lokal di perangkat; tidak ada server atau sinkronisasi cloud.
- Aplikasi tidak meminta PIN, OTP, kata sandi, atau akses untuk mengirim uang.
- Android membatasi akses notifikasi; pengguna harus mengaktifkan akses secara eksplisit di Settings.
