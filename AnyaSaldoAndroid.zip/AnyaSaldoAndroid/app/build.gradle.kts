plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.anyasaldo.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.anyasaldo.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
