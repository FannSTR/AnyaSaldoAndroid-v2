package id.anyasaldo.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.security.MessageDigest

class DanaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // DANA Android package ID commonly used by the official app.
        if (sbn.packageName != "id.dana") return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString(" ").orEmpty()
        val message = listOf(title, text, bigText, lines).filter { it.isNotBlank() }.distinct().joinToString(" ")
        if (message.isBlank()) return

        // Conservative positive wording checks to avoid treating payment receipts/outgoing
        // transfers as incoming money. Notification wording can vary by DANA version.
        val lower = message.lowercase()
        val incoming = listOf(
            "menerima uang", "kamu menerima", "uang masuk", "terima uang",
            "berhasil menerima", "menerima saldo", "dana masuk"
        ).any { lower.contains(it) }
        if (!incoming) return

        val amount = parseRupiah(message) ?: return
        // Stable enough to ignore repeated callbacks for the same notification while allowing
        // separate payments of the same amount. Do not save the notification text itself.
        val keyMaterial = "${sbn.packageName}|${sbn.key}|${sbn.postTime}|$amount"
        val key = sha256(keyMaterial)
        TransactionStore.addIncomingDANA(applicationContext, amount, key)
    }

    private fun parseRupiah(text: String): Long? {
        val regex = Regex("""(?i)Rp\.?\s*([0-9][0-9.,]*)""")
        val match = regex.findAll(text).lastOrNull() ?: return null
        val digits = match.groupValues[1].replace(".", "").replace(",", "").filter { it.isDigit() }
        return digits.toLongOrNull()?.takeIf { it > 0 }
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }
}
