package id.anyasaldo.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class WalletTransaction(
    val id: String,
    val type: String,
    val amount: Long,
    val description: String,
    val category: String,
    val timestamp: Long,
    val sourceKey: String = ""
)

object TransactionStore {
    private const val PREFS = "anya_wallet"
    private const val TX_KEY = "transactions"
    private const val SEEN_KEY = "seen_notifications"

    @Synchronized
    fun all(context: Context): List<WalletTransaction> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(TX_KEY, "[]") ?: "[]"
        val result = mutableListOf<WalletTransaction>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(WalletTransaction(
                    o.optString("id"), o.optString("type"), o.optLong("amount"),
                    o.optString("description"), o.optString("category"), o.optLong("timestamp"),
                    o.optString("sourceKey")
                ))
            }
        } catch (_: Exception) {}
        return result.sortedByDescending { it.timestamp }
    }

    @Synchronized
    private fun save(context: Context, items: List<WalletTransaction>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("type", it.type).put("amount", it.amount)
                .put("description", it.description).put("category", it.category)
                .put("timestamp", it.timestamp).put("sourceKey", it.sourceKey))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TX_KEY, arr.toString()).apply()
    }

    @Synchronized
    fun addManual(context: Context, type: String, amount: Long, description: String) {
        if (amount <= 0) return
        val item = WalletTransaction(
            System.currentTimeMillis().toString() + (0..999).random(),
            type, amount, description.trim().ifBlank { if (type == "income") "Pemasukan" else "Pengeluaran" },
            "Manual", System.currentTimeMillis()
        )
        save(context, all(context) + item)
    }

    @Synchronized
    fun addIncomingDANA(context: Context, amount: Long, sourceKey: String): Boolean {
        if (amount <= 0) return false
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = prefs.getStringSet(SEEN_KEY, emptySet())?.toMutableSet() ?: mutableSetOf()
        if (sourceKey in seen) return false
        val item = WalletTransaction(
            "dana_" + sourceKey.hashCode().toUInt().toString(16),
            "income", amount, "Pemasukan otomatis DANA", "Transfer DANA", System.currentTimeMillis(), sourceKey
        )
        save(context, all(context) + item)
        seen.add(sourceKey)
        // Keep the de-duplication cache bounded.
        while (seen.size > 500) seen.remove(seen.first())
        prefs.edit().putStringSet(SEEN_KEY, seen).apply()
        return true
    }

    fun formatRupiah(amount: Long): String =
        "Rp" + String.format(Locale("id", "ID"), "%,d", amount).replace(',', '.')

    fun formatDate(timestamp: Long): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID")).format(Date(timestamp))
}
