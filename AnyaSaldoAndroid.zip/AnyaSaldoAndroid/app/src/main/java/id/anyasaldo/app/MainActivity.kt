package id.anyasaldo.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val pink = Color.rgb(231, 107, 157)
    private val ink = Color.rgb(59, 45, 59)
    private val muted = Color.rgb(143, 123, 140)
    private val pale = Color.rgb(255, 244, 249)
    private lateinit var root: LinearLayout
    private lateinit var summary: TextView
    private lateinit var totals: TextView
    private lateinit var status: TextView
    private lateinit var history: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(255, 248, 251)
        window.navigationBarColor = Color.rgb(255, 248, 251)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) refresh()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(255, 248, 251)) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "🌸  Anya Saldo\nCatatan uang kecil, mimpi besar ✨"
            setTextColor(ink); textSize = 23f; setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, dp(16))
        }
        root.addView(header)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = rounded(pink, 24)
        }
        hero.addView(label("TOTAL SALDO SEKARANG", Color.rgb(91, 48, 69), 13f))
        summary = label("Rp0", Color.WHITE, 34f).apply { setTypeface(null, Typeface.BOLD); setPadding(0, dp(7), 0, dp(8)) }
        hero.addView(summary)
        hero.addView(label("♡ Dompet pribadi  •  Semangat menabung!", Color.WHITE, 12f))
        root.addView(hero, params(bottom = 12))

        totals = label("", ink, 14f).apply {
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = rounded(Color.WHITE, 18)
        }
        root.addView(totals, params(bottom = 12))

        val enable = button("🔔  Aktifkan deteksi notifikasi DANA")
        enable.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        root.addView(enable, params(bottom = 8))

        status = label("", muted, 12f).apply { setPadding(dp(3), dp(2), dp(3), dp(14)) }
        root.addView(status)

        val manual = button("＋ Tambah pemasukan / pengeluaran")
        manual.setOnClickListener { showAddDialog() }
        root.addView(manual, params(bottom = 18))

        root.addView(label("🧾  Riwayat transaksi", ink, 19f).apply {
            setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, dp(10))
        })
        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(history)
        root.addView(label(
            "Privasi: aplikasi hanya memproses notifikasi dari paket DANA yang cocok dan menyimpan nominal serta waktu transaksi di perangkat. Tidak perlu PIN, OTP, atau kata sandi DANA. Cocokkan saldo otomatis dengan riwayat DANA secara berkala.",
            muted, 11f
        ).apply { setPadding(dp(3), dp(18), dp(3), 0) })
        refresh()
    }

    private fun refresh() {
        val all = TransactionStore.all(this)
        val income = all.filter { it.type == "income" }.sumOf { it.amount }
        val expense = all.filter { it.type == "expense" }.sumOf { it.amount }
        summary.text = TransactionStore.formatRupiah(income - expense)
        totals.text = "💖 PEMASUKAN  ${TransactionStore.formatRupiah(income)}\n\n🛍️ PENGELUARAN  ${TransactionStore.formatRupiah(expense)}\n\n📚 ${all.size} transaksi tercatat"
        val enabled = isNotificationAccessEnabled()
        status.text = if (enabled) "● Akses notifikasi aktif. Menunggu notifikasi uang masuk DANA." else "○ Akses notifikasi belum aktif. Tekan tombol di atas, lalu izinkan Anya Saldo."
        history.removeAllViews()
        if (all.isEmpty()) {
            history.addView(label("🌷 Belum ada transaksi. Pemasukan DANA akan muncul di sini setelah notifikasi terdeteksi.", muted, 13f).apply {
                setPadding(dp(16), dp(24), dp(16), dp(24)); gravity = Gravity.CENTER
                background = rounded(Color.WHITE, 18)
            })
            return
        }
        all.take(100).forEach { tx ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(13), dp(12), dp(13), dp(12))
                background = rounded(Color.WHITE, 16)
            }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            left.addView(label((if (tx.type == "income") "💖 " else "🛍️ ") + tx.description, ink, 13f).apply { setTypeface(null, Typeface.BOLD) })
            left.addView(label("${tx.category} · ${TransactionStore.formatDate(tx.timestamp)}", muted, 10f).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(label((if (tx.type == "income") "+" else "−") + TransactionStore.formatRupiah(tx.amount),
                if (tx.type == "income") Color.rgb(38, 141, 105) else Color.rgb(217, 87, 112), 13f).apply { setTypeface(null, Typeface.BOLD) })
            history.addView(row, params(bottom = 7))
        }
    }

    private fun showAddDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(6), dp(22), 0) }
        val typeSpinner = Spinner(this)
        typeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Pemasukan", "Pengeluaran"))
        val amount = EditText(this).apply { hint = "Nominal, contoh 25000"; inputType = 2 }
        val desc = EditText(this).apply { hint = "Keterangan transaksi" }
        box.addView(label("Jenis transaksi", ink, 13f)); box.addView(typeSpinner)
        box.addView(label("Jumlah (Rupiah)", ink, 13f)); box.addView(amount)
        box.addView(label("Keterangan", ink, 13f)); box.addView(desc)
        AlertDialog.Builder(this).setTitle("♡ Tambah transaksi").setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val value = amount.text.toString().trim().toLongOrNull()
                        if (value == null || value <= 0) { amount.error = "Masukkan nominal yang benar"; return@setOnClickListener }
                        val type = if (typeSpinner.selectedItemPosition == 0) "income" else "expense"
                        TransactionStore.addManual(this, type, value, desc.text.toString())
                        dialog.dismiss()
                        refresh()
                    }
                }
                dialog.show()
            }
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        background = rounded(pink, 16); setPadding(dp(12), dp(7), dp(12), dp(7))
    }

    private fun label(text: String, color: Int, size: Float) = TextView(this).apply {
        this.text = text; setTextColor(color); textSize = size
    }

    private fun params(bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(bottom) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
        }
}
